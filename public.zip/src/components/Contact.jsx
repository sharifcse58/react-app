import React, { Component } from 'react'
import styled from 'styled-components'
import { Link } from 'react-router-dom'
import '../css/style.css'

const Container = styled.div.attrs({
    className: 'container',
})``



class Contact extends Component {
    render() {
        return (
            <div class="common-card"><div>About my contacts</div></div> 
        )
    }
}

export default Contact